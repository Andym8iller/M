To run, just download the .Zip file and run Index.html or go to the github.io website and if you have any problems or suggestions, just make an issue.
